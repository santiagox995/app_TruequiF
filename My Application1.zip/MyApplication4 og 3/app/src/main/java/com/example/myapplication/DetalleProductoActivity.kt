package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.myapplication.adapter.FotoAdapter
import com.example.myapplication.model.Producto
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class DetalleProductoActivity : AppCompatActivity() {

    private lateinit var viewPagerFotos: ViewPager2
    private lateinit var tvUsuario: TextView
    private lateinit var tvTitulo: TextView
    private lateinit var tvDescripcion: TextView
    private lateinit var tvEstado: TextView
    private lateinit var tvCategoria: TextView
    private lateinit var btnEditar: android.widget.Button
    private lateinit var btnEliminar: android.widget.Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_producto)

        // Vincular vistas
        viewPagerFotos = findViewById(R.id.viewPagerFotos)
        tvUsuario = findViewById(R.id.tvUsuario)
        tvTitulo = findViewById(R.id.tvTitulo)
        tvDescripcion = findViewById(R.id.tvDescripcion)
        tvEstado = findViewById(R.id.tvEstado)
        tvCategoria = findViewById(R.id.tvCategoria)
        btnEditar = findViewById(R.id.btnEditar)
        btnEliminar = findViewById(R.id.btnEliminar)

        try {
            val producto = intent.getSerializableExtra("producto") as? Producto

            if (producto != null) {
                tvUsuario.text = producto.usuario.ifEmpty { "Usuario desconocido" }
                tvTitulo.text = producto.titulo.ifEmpty { "Sin título" }
                tvDescripcion.text = producto.descripcion.ifEmpty { "Sin descripción" }
                tvEstado.text = producto.estado.ifEmpty { "No especificado" }
                tvCategoria.text = producto.categoria.ifEmpty { "No especificada" }

                if (producto.imagenes.isNotEmpty()) {
                    viewPagerFotos.adapter = FotoAdapter(producto.imagenes)
                } else {
                    Toast.makeText(this, "Este producto no tiene imágenes.", Toast.LENGTH_SHORT).show()
                }

                val userId = FirebaseAuth.getInstance().currentUser?.uid

                if (producto.creadorUID == userId) {
                    btnEditar.visibility = android.view.View.VISIBLE
                    btnEliminar.visibility = android.view.View.VISIBLE
                } else {
                    btnEditar.visibility = android.view.View.GONE
                    btnEliminar.visibility = android.view.View.GONE
                }

                // 🗑 Botón eliminar (usando la estructura productos/UID/productoID)
                btnEliminar.setOnClickListener {
                    if (producto.creadorUID != null) {
                        val ref = FirebaseDatabase.getInstance()
                            .getReference("productos")
                            .child(producto.creadorUID)
                            .child(producto.id)

                        ref.removeValue()
                            .addOnSuccessListener {
                                Toast.makeText(this, "Producto eliminado", Toast.LENGTH_SHORT).show()
                                finish()
                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "Error al eliminar", Toast.LENGTH_SHORT).show()
                            }
                    } else {
                        Toast.makeText(this, "No se encontró el ID del creador", Toast.LENGTH_SHORT).show()
                    }
                }

                // ✏️ Botón editar
                btnEditar.setOnClickListener {
                    val intent = Intent(this, EditarProductoActivity::class.java)
                    intent.putExtra("producto", producto)
                    startActivity(intent)
                }

            } else {
                Toast.makeText(this, "No se pudo cargar el producto", Toast.LENGTH_LONG).show()
                finish()
            }

        } catch (e: Exception) {
            Toast.makeText(this, "Error al cargar producto: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
            finish()
        }

        // Menú inferior
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.like -> {
                    startActivity(Intent(this, LikeActivity::class.java))
                    true
                }
                R.id.añadir -> {
                    startActivity(Intent(this, AgregarActivity::class.java))
                    true
                }
                R.id.buzon -> {
                    startActivity(Intent(this, BuzonActivity::class.java))
                    true
                }
                R.id.nav_perfil -> {
                    startActivity(Intent(this, PerfilActivity::class.java))
                    true
                }
                else -> false
            }
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
