package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.ProductoAdapter
import com.example.myapplication.model.Producto
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import android.widget.ImageButton
import android.widget.PopupMenu


class PerfilActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var textViewNombre: TextView
    private lateinit var recyclerView: RecyclerView

    private val productoList = mutableListOf<Producto>()
    private lateinit var productoAdapter: ProductoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        val btnMenu = findViewById<ImageButton>(R.id.btn_menu)
        btnMenu.setOnClickListener {
            val popup = PopupMenu(this, btnMenu)
            popup.menuInflater.inflate(R.menu.perfil_menu, popup.menu)

            popup.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.menu_mis_datos -> {
                        // Acción para "Mis datos"
                        startActivity(Intent(this, MisDatosActivity::class.java)) // cambia si usas otra
                        true
                    }
                    R.id.menu_cerrar_sesion -> {
                        auth.signOut()
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                        true
                    }
                    R.id.menu_eliminar_cuenta -> {
                        // Acción para eliminar cuenta (ejemplo simple)
                        val user = auth.currentUser
                        user?.delete()?.addOnCompleteListener {
                            if (it.isSuccessful) {
                                startActivity(Intent(this, LoginActivity::class.java))
                                finish()
                            }
                        }
                        true
                    }
                    else -> false
                }
            }

            popup.show()
        }




        // Inicializar Firebase
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // Referencias UI
        textViewNombre = findViewById(R.id.textViewNombre)
        recyclerView = findViewById(R.id.recyclerView)

        // Configurar RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        productoAdapter = ProductoAdapter(productoList) { producto ->
            val intent = Intent(this, DetalleProductoActivity::class.java)
            intent.putExtra("producto", producto) // debe implementar Serializable
            startActivity(intent)
        }

        recyclerView.adapter = productoAdapter

        // Obtener UID actual
        val userId = auth.currentUser?.uid
        if (userId != null) {
            mostrarNombreUsuario(userId)
        } else {
            textViewNombre.text = "Usuario no autenticado"
        }

        // Navegación inferior
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNav.selectedItemId = R.id.nav_perfil

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }
                R.id.like -> {
                    startActivity(Intent(this, LikeActivity::class.java))
                    true
                }
                R.id.añadir -> {
                    startActivity(Intent(this, AgregarActivity::class.java))
                    true
                }
                R.id.buzon -> {
                    startActivity(Intent(this, BuzonActivity::class.java))
                    true
                }
                R.id.nav_perfil -> true
                else -> false
            }
        }
    }

    private fun mostrarNombreUsuario(userId: String) {
        val nombreRef = database.child("Usuarios").child(userId).child("nombre")
        nombreRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val nombre = snapshot.getValue(String::class.java)
                textViewNombre.text = nombre ?: "Nombre no disponible"

                // Cargar productos una vez tengamos el nombre
                cargarProductosDelUsuario(userId, textViewNombre.text.toString())
            }

            override fun onCancelled(error: DatabaseError) {
                textViewNombre.text = "Error al cargar nombre"
            }
        })
    }

    private fun cargarProductosDelUsuario(userId: String, nombreUsuario: String) {
        val productosRef = database.child("productos").child(userId)
        productoList.clear()

        productosRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (productoSnap in snapshot.children) {
                    try {
                        val producto = productoSnap.getValue(Producto::class.java)
                        producto?.let {
                            it.id = productoSnap.key ?: ""
                            it.usuario = nombreUsuario
                            productoList.add(it)
                        }
                    } catch (e: Exception) {
                        println("Error al convertir producto: ${productoSnap.value}")
                        e.printStackTrace()
                    }
                }
                productoAdapter.notifyDataSetChanged()

            }

            override fun onCancelled(error: DatabaseError) {
                // Manejar error si es necesario
            }
        })
    }
}
