package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.ChatAdapter
import com.example.myapplication.model.Mensaje
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

// ────────────────────────────────────────────
// 1️⃣ Definición de datos
// ────────────────────────────────────────────
data class AssistantMessage(
    val role: String,
    val content: String
)

data class AssistantRequest(
    val model: String = "gpt-4",
    val messages: List<AssistantMessage>
)

data class AssistantResponse(
    val choices: List<AssistantChoice>
)

data class AssistantChoice(
    val message: AssistantMessage
)

// ────────────────────────────────────────────
// 2️⃣ Servicio Retrofit para OpenAI
// ────────────────────────────────────────────
interface TruequiBotService {
    @Headers(
        "Content-Type: application/json"
    )
    @POST("v1/chat/completions")
    suspend fun getAssistantCompletion(
        @Header("Authorization") authorization: String,
        @Body requestBody: AssistantRequest
    ): Response<AssistantResponse>
}

// ────────────────────────────────────────────
// 3️⃣ Actividad principal: TruequiBotActivity
// ────────────────────────────────────────────
class TruequiBotActivity : AppCompatActivity() {

    // Clave de API
    private val apiKey = "Bearer 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"

    // UI
    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var inputMessage: EditText
    private lateinit var sendButton: Button
    private lateinit var chatAdapter: ChatAdapter
    private val messageList = mutableListOf<Mensaje>()

    // Retrofit
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openai.com/")
        .client(OkHttpClient())
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val service = retrofit.create(TruequiBotService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_truequibot)

        // Inicializar UI
        chatRecyclerView = findViewById(R.id.chatRecyclerView)
        inputMessage = findViewById(R.id.input_message)
        sendButton = findViewById(R.id.send_button)

        // Configuración del RecyclerView
        chatAdapter = ChatAdapter(messageList)
        chatRecyclerView.layoutManager = LinearLayoutManager(this)
        chatRecyclerView.adapter = chatAdapter

        // Listener para enviar el mensaje
        sendButton.setOnClickListener {
            val userText = inputMessage.text.toString().trim()
            if (userText.isNotEmpty()) {
                addUserMessage(userText)
                inputMessage.text.clear()
                callAssistant(userText)
            }
        }
    }

    // Función para agregar el mensaje del usuario al chat
    private fun addUserMessage(text: String) {
        messageList.add(Mensaje(text, "user"))
        chatAdapter.notifyItemInserted(messageList.size - 1)
        chatRecyclerView.scrollToPosition(messageList.size - 1)
    }

    // Función para agregar el mensaje del bot al chat
    private fun simulateBotResponse(text: String) {
        messageList.add(Mensaje(text, "bot"))
        chatAdapter.notifyItemInserted(messageList.size - 1)
        chatRecyclerView.scrollToPosition(messageList.size - 1)
    }

    // Función para llamar al asistente
    private fun callAssistant(userInput: String) {
        val body = AssistantRequest(
            model = "gpt-4o-mini",
            messages = listOf(
                AssistantMessage("system", "You are TruequiBot, a chat assistant."),
                AssistantMessage("user", userInput)
            )
        )

        GlobalScope.launch(Dispatchers.Main) {
            try {
                val resp = service.getAssistantCompletion(apiKey, body)
                if (resp.isSuccessful) {
                    val choices = resp.body()?.choices
                    val content = choices
                        ?.firstOrNull()
                        ?.message
                        ?.content
                    simulateBotResponse(content ?: "❌ Respuesta vacía")
                } else {
                    simulateBotResponse("❌ Error ${resp.code()} al llamar al asistente")
                }
            } catch (e: Exception) {
                Log.e("TruequiBot", "API error: ${e.message}")
                simulateBotResponse("❌ No se pudo procesar la solicitud. Intenta de nuevo.")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
